# Zeus-style BTC target dashboard
Responsive chart-first dashboard inspired by the supplied screenshot. Includes BTC/ETH/SOL/XRP tabs, 1m/5m/15m candles, Candles/Smooth/Line views, target/support/resistance overlays, countdown, and Your Bets / Zeus Settings / Zeus Log panels.

Data: Kalshi public `KXBTC15M` market metadata and Coinbase Exchange OHLCV candles. Only BTC displays the Kalshi target. Other assets are chart-only. Support/resistance are recent-candle range references. Bets and bot settings are placeholders, not connected to a trading bot. Coinbase prices can differ from Kalshi's official settlement index.

Deploy the repository to Cloudflare Workers using `npx wrangler deploy`. Verify `/api/market` returns the exact currently active ticker and `floor_strike` before relying on it. Do not trade on stale or mismatched data.
